# Nurture
A website for education and empowerment of adolescent girls. Teenage girls can know about various changes that happen during the life of a girl. They can seek help or ask questions without any hesistation.
![image](https://github.com/khushi767/Nurture/assets/99918465/d555d8ac-9e00-47cf-b4fb-fb8ed0e1fa96)

